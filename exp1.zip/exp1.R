#Packages

library(ggplot2)
library(tidyverse)
library(readxl)
library(ggpubr)
library(ggprism)
library(dplyr)
library(ggsignif)
library("pscl")           ## count regression tools
library("glmmTMB")        ## count regression implementation (Frequentist, also allows for mixed-effects extensions)
library("DHARMa")         ## GLM residuals and dispersion checks
library("effects")
library("sjPlot")
library("car")
library("lmtest")
library("GGally")         ## ggplot scatterplot matrix
library("ggpubr")
library("performance")
library(lme4)
library(lmerTest)

#Exp1

#1. First fixation
#1.1 First fixation distribution

FFixN<-read_xlsx(file.choose())
FFixN<-as_tibble(FFixN)
as.data.frame(FFixN)
str(FFixN)

AT3T3<-subset(FFixN, FFixN$`Auditory Stimuli`=='T3-T3')
AT2T3<-subset(FFixN, FFixN$`Auditory Stimuli`=='T2-T3')
ASEG<-subset(FFixN, FFixN$`Auditory Stimuli`=='SEG')
ASUPR<-subset(FFixN, FFixN$`Auditory Stimuli`=='SUPR')

levels(AT3T3$`Auditory Stimuli`)<-c('T3-T3','T2-T3','SEG','SUPR')
levels(AT3T3$`Auditory Stimuli`)


AT3T3

p1<-ggplot(AT3T3,aes(x=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=`Number of first fixations`, fill=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  geom_bar(stat='identity', width = 0.5)+
  ggtitle("Auditory Stimuli: T3-T3") +
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=12))+
  labs(x = "Visual Stimuli", y = "Number of first fixations")+
  theme(legend.title = element_blank())+
  theme(text = element_text(family = "serif"))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  geom_col(width = 0.2,position = position_dodge(0.5))+ 
  annotate("text", x=3.5, y=125, label= "*",size=10)
p1

p2<-ggplot(AT2T3,aes(x=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=`Number of first fixations`, fill=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  geom_bar(stat='identity', width=0.5)+
  ggtitle("Auditory Stimuli: T2-T3") +
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=12))+
  labs(x = "Visual Stimuli", y = "Number of first fixations")+
  theme(legend.title = element_blank())+
  theme(text = element_text(family = "serif"))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  geom_col(width = 0.2)+ 
  annotate("text", x=3.5, y=125, label= "*",size=10)
p2  
  
p3<-ggplot(ASEG,aes(x=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=`Number of first fixations`, fill=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  geom_bar(stat='identity', width=0.5)+
  ggtitle("Auditory Stimuli: SEG") +
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=12))+
  labs(x = "Visual Stimuli", y = "Number of first fixations")+
  theme(legend.title = element_blank())+
  theme(text = element_text(family = "serif"))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  geom_col(width = 0.2)

p3





p4<-ggplot(ASUPR,aes(x=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=`Number of first fixations`, fill=factor(`Visual Stimuli`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  geom_bar(stat='identity', width=0.5)+
  ggtitle("Auditory Stimuli: SUPR") +
  theme_classic()+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=12))+
  labs(x = "Visual Stimuli", y = "Number of first fixations")+
  theme(legend.title = element_blank())+
  theme(text = element_text(family = "serif"))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))
p4

ggarrange(p1,p2,p3,p4,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

#1.1.2 Chi-square

SAN<-c(137,127,104,94)
chisq.test(SAN)
ER<-c(140,126,97,92)
chisq.test(ER)
SEG<-c(48,62,55,53)
chisq.test(SEG)
SUPR<-c(43,57,57,60)
chisq.test(SUPR)

#First fixation duration

FFD<-read_xlsx(file.choose())
FFD<-as_tibble(FFD)

aggregate(FFD$CURRENT_FIX_DURATION, by=list(FFD$CURRENT_FIX_INTEREST_AREA_LABEL,FFD$soud1), FUN=mean)
aggregate(FFD$CURRENT_FIX_DURATION, by=list(FFD$CURRENT_FIX_INTEREST_AREA_LABEL,FFD$soud1), FUN=sd)

FFD$CURRENT_FIX_INTEREST_AREA_LABEL<-recode_factor(FFD$CURRENT_FIX_INTEREST_AREA_LABEL, er='T2-T3',san='T3-T3',seg='SEG',supr='SUPR')

FFDT3<-subset(FFD, FFD$soud1=='SAN')
FFDT2<-subset(FFD, FFD$soud1=='ER')
FFDSEG<-subset(FFD, FFD$soud1=='SEG')
FFDSUPR<-subset(FFD, FFD$soud1=='SUPR')

p5<-ggplot(FFDT3,aes(x=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=CURRENT_FIX_DURATION,number,fill=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position='dodge',width=.5)+
  labs(x="Visual Stimuli", y=" Meand duration of first fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
  geom = "errorbar",
  position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
  breaks=c("er", "san", "seg",'supr'),
  labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))
  
p5

p6<-ggplot(FFDT2,aes(x=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=CURRENT_FIX_DURATION,number,fill=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position='dodge',width=.5)+
  labs(x="Visual Stimuli", y=" Meand duration of first fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))

p6

p7<-ggplot(FFDSEG,aes(x=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=CURRENT_FIX_DURATION,number,fill=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=.5)+
  labs(x="Visual Stimuli", y=" Meand duration of first fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                    breaks=c("er", "san", "seg",'supr'),
                    labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))

p7
p8<-ggplot(FFDSEG,aes(x=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=CURRENT_FIX_DURATION,number,fill=factor(`CURRENT_FIX_INTEREST_AREA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y=" Meand duration of first fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))

p8
ggarrange(p5,p6,p7,p8,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

#P1 

P1<-read_xlsx(file.choose())
P1<-as_tibble(P1sac)
P1$IA_LABEL<-recode_factor(P1$IA_LABEL, er='T2-T3',san='T3-T3',seg='SEG',supr='SUPR')

aggregate(P1$IA_FIXATION_COUNT, by=list(P1$IA_LABEL,P1$soud1), FUN=mean)
aggregate(P1$IA_FIXATION_COUNT, by=list(P1$IA_LABEL,P1$soud1), FUN=sd)

aggregate(P1$M_DUR, by=list(P1$IA_LABEL,P1$soud1), FUN=mean)
aggregate(P1$M_DUR, by=list(P1$IA_LABEL,P1$soud1), FUN=sd)

P1T3<-subset(P1, P1$soud1=='SAN')
P1T2<-subset(P1, P1$soud1=='ER')
P1SEG<-subset(P1, P1$soud1=='SEG')
P1SUPR<-subset(P1, P1$soud1=='SUPR')

#model

#T3-T3

levels(P1T3$IA_LABEL)
P1T3$IA_LABEL<-relevel(P1T3$IA_LABEL,ref = 'T3-T3')
levels(P1T3$IA_LABEL)
str(P1T3)

fit_P1san <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P1T3, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P1san

summary(fit_P1san)  

#T2-T3

levels(P1T2$IA_LABEL)

fit_P1er <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P1T2, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P1er

summary(fit_P1er)    


#SEG.
levels(P1SEG$IA_LABEL)
P1SEG$IA_LABEL<-relevel(P1SEG$IA_LABEL,ref = 'SEG')
levels(P1SEG$IA_LABEL)
str(P1T3)

fit_P1SEG <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P1SEG, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P1SEG
summary(fit_P1SEG)  

#SUPR
levels(P1SUPR$IA_LABEL)
P1SUPR$IA_LABEL<-relevel(P1SUPR$IA_LABEL,ref = 'SUPR')
levels(P1SUPR$IA_LABEL)
str(P1SUPR)

fit_P1SUPR <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P1SUPR, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P1SUPR
summary(fit_P1SUPR)  

#fig

p9<-ggplot(P1T3,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2, y = 0.45, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 0.5, 
           label = "***",
           size = 6, color = "#22292F")

p9
  

p10<-ggplot(P1T2,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2.5, y = 0.45, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 0.5, 
           label = "*",
           size = 6, color = "#22292F")


p10

p11<-ggplot(P1SEG,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 3.5, y = 0.5, 
           label = "***",
           size = 6, color = "#22292F")

p11

p12<-ggplot(P1SUPR,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 3.5, y = 0.5, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 0.55, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 0.6, 
           label = "***",
           size = 6, color = "#22292F")

p12

ggarrange(p9,p10,p11,p12,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

#P2

P2<-read_xlsx(file.choose())
P2<-as_tibble(P2)
P2$IA_LABEL<-recode_factor(P2$IA_LABEL, er='T2-T3',san='T3-T3',seg='SEG',supr='SUPR')

aggregate(P2$IA_FIXATION_COUNT, by=list(P2$IA_LABEL,P2$soud1), FUN=mean)
aggregate(P2$IA_FIXATION_COUNT, by=list(P2$IA_LABEL,P2$soud1), FUN=sd)

aggregate(P2$M_DUR, by=list(P2$IA_LABEL,P2$soud1), FUN=mean)
aggregate(P2$M_DUR, by=list(P2$IA_LABEL,P2$soud1), FUN=sd)

P2T3<-subset(P2, P2$soud1=='SAN')
P2T2<-subset(P2, P2$soud1=='ER')
P2SEG<-subset(P2, P2$soud1=='SEG')
P2SUPR<-subset(P2, P2$soud1=='SUPR')

#model

#T3-T3

levels(P2T3$IA_LABEL)
P2T3$IA_LABEL<-relevel(P2T3$IA_LABEL,ref = 'T3-T3')
levels(P2T3$IA_LABEL)
str(P2T3)

fit_P2san <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2T3, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P2san

summary(fit_P2san)  

#T2-T3

levels(P2T2$IA_LABEL)

fit_P2er <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2T2, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P2er

summary(fit_P2er)    


#SEG.
levels(P2SEG$IA_LABEL)
P2SEG$IA_LABEL<-relevel(P2SEG$IA_LABEL,ref = 'SEG')
levels(P2SEG$IA_LABEL)
str(P2T3)

fit_P2SEG <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2SEG, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P2SEG
summary(fit_P2SEG)  

#SUPR
levels(P2SUPR$IA_LABEL)
P2SUPR$IA_LABEL<-relevel(P2SUPR$IA_LABEL,ref = 'SUPR')
levels(P2SUPR$IA_LABEL)
str(P2SUPR)

fit_P2SUPR <- glmmTMB(IA_FIXATION_COUNT ~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2SUPR, family = "nbinom2")   ## dot notation for including all the variables as predictors
fit_P2SUPR
summary(fit_P2SUPR)  

#fig

p13<-ggplot(P2T3,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.6, 
           label = "***",
           size = 6, color = "#22292F")

p13+geom_rect(
  aes(xmin = "T3-T3", xmax = "T2-T3", ymin = 2.14, ymax = 2.145),
  fill = "black",
  alpha = 0.2
)


P14<-ggplot(P2T2,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 2.6, 
           label = "***",
           size = 6, color = "#22292F")

P14

P15<-ggplot(P2SEG,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2, y = 2.6, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")

P15
P16<-ggplot(P2SUPR,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2.5, y = 2.6, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")

P16

ggarrange(p13,P14,P15,P16,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

#P2 Meand Dur

#T3-T3

levels(P2T3$IA_LABEL)
P2T3$IA_LABEL<-relevel(P2T3$IA_LABEL,ref = 'T3-T3')
levels(P2T3$IA_LABEL)
str(P2T3)

fit_P2san <- lmer(M_DUR~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2T3, REML=FALSE)   ## dot notation for including all the variables as predictors
fit_P2san

summary(fit_P2san)
anova(fit_P2san)

#T2-T3

levels(P2T2$IA_LABEL)

fit_P2er <- lmer(M_DUR~IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2T2, REML=FALSE)   ## dot notation for including all the variables as predictors
fit_P2er

summary(fit_P2er)    


#SEG.
levels(P2SEG$IA_LABEL)
P2SEG$IA_LABEL<-relevel(P2SEG$IA_LABEL,ref = 'SEG')
levels(P2SEG$IA_LABEL)
str(P2T3)

fit_P2SEG <- lmer(M_DUR~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2SEG, REML=FALSE)   ## dot notation for including all the variables as predictors
fit_P2SEG
summary(fit_P2SEG)  

#SUPR
levels(P2SUPR$IA_LABEL)
P2SUPR$IA_LABEL<-relevel(P2SUPR$IA_LABEL,ref = 'SUPR')
levels(P2SUPR$IA_LABEL)
str(P2SUPR)

fit_P2SUPR <- lmer(M_DUR~ IA_LABEL+(1|RECORDING_SESSION_LABEL)+(1|pic),data = P2SUPR, REML=FALSE)   ## dot notation for including all the variables as predictors
fit_P2SUPR
summary(fit_P2SUPR)

#plot P2 mean dur

p13<-ggplot(P2T3,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 280, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2, y = 305, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 330, 
           label = "***",
           size = 6, color = "#22292F")

p13


P14<-ggplot(P2T2,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli",y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 275, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 300, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 325, 
           label = "***",
           size = 6, color = "#22292F")

P14

P15<-ggplot(P2SEG,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli",y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2, y = 380, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 330, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 355, 
           label = "***",
           size = 6, color = "#22292F")

P15
P16<-ggplot(P2SUPR,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2.5, y = 385, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 360, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 335, 
           label = "***",
           size = 6, color = "#22292F")

P16

ggarrange(p13,P14,P15,P16,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

#P3 fig

#fig1
p13<-ggplot(P2T3,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")

p13


P14<-ggplot(P2T2,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")

P14

P15<-ggplot(P2SEG,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 2.0, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")

P15
P16<-ggplot(P2SUPR,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=IA_FIXATION_COUNT,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Number of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2.5, y = 2.4, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 2.2, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 2, 
           label = "***",
           size = 6, color = "#22292F")

P16

ggarrange(p13,P14,P15,P16,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)


#MEAN DUR

p13<-ggplot(P2T3,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T3-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 430, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2, y = 470, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 510, 
           label = "***",
           size = 6, color = "#22292F")

p13


P14<-ggplot(P2T2,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli",y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: T2-T3")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 1.5, y = 420, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 460, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 500, 
           label = "***",
           size = 6, color = "#22292F")

P14

P15<-ggplot(P2SEG,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli",y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SEG")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2, y = 530, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 2.5, y = 450, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 490, 
           label = "***",
           size = 6, color = "#22292F")

P15
P16<-ggplot(P2SUPR,aes(x=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR')),y=M_DUR,number,fill=factor(`IA_LABEL`,level=c('T3-T3','T2-T3','SEG','SUPR'))))+
  stat_summary(fun = mean,geom="bar",position="dodge",width=0.5)+
  labs(x="Visual Stimuli", y="Mean duration of fixation")+
  theme_classic()+
  ggtitle("Auditory Stimuli: SUPR")+
  stat_summary(fun.data = mean_cl_normal,
               geom = "errorbar",
               position=position_dodge(width = 0.9),width=.1)+
  theme(legend.title = element_blank())+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(text=element_text(size=15))+
  theme(text = element_text(family = "serif"))+
  scale_fill_discrete(name="Experimental\nCondition",
                      breaks=c("er", "san", "seg",'supr'),
                      labels=c("T2", "t3", "SEG",'SUPR'))+
  scale_fill_manual(values=c("#FF6666","#6699ff","#ffcc66","#66ffcc"))+
  annotate("text", x = 2.5, y = 530, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3, y = 490, 
           label = "***",
           size = 6, color = "#22292F")+
  annotate("text", x = 3.5, y = 450, 
           label = "***",
           size = 6, color = "#22292F")

P16

ggarrange(p13,P14,P15,P16,labels=c('(a)','(b)','(c)','(d)'),ncol=2,nrow=2)

# Create sample data
data <- data.frame(
  group = c("A", "B", "C", "D"),
  value = c(20, 40, 35, 50)
)

# Create a bar plot with ggplot2
p <- ggplot(data, aes(x = group, y = value, fill = group)) +
  geom_bar(stat = "identity")

# Add a level bar
p + geom_rect(
  aes(xmin = "B", xmax = "C", ymin = 42, ymax = 42.1),
  fill = "black",
  alpha = 0.2
)
